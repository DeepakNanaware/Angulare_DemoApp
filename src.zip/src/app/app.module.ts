import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { CoursesComponent } from './component/courses/courses.component';
import { ContactComponent } from './component/contact/contact.component';
import { JavaComponent } from './component/courses/java/java.component';
import { PythonComponent } from './component/courses/python/python.component';
import { NotFoundComponent } from './component/not-found/not-found.component';
import { PostsComponent } from './component/posts/posts.component';
import { UsersComponent } from './component/users/users.component';
import { TodosComponent } from './component/todos/todos.component';
import { AlbumsComponent } from './component/albums/albums.component';
import { CommentsComponent } from './component/comments/comments.component';
import { PhotosComponent } from './component/photos/photos.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CoursesComponent,
    ContactComponent,
    JavaComponent,
    PythonComponent,
    NotFoundComponent,
    PostsComponent,
    UsersComponent,
    TodosComponent,
    AlbumsComponent,
    CommentsComponent,
    PhotosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
