import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AlbumsComponent } from './component/albums/albums.component';
import { CommentsComponent } from './component/comments/comments.component';
import { ContactComponent } from './component/contact/contact.component';
import { CoursesComponent } from './component/courses/courses.component';
import { JavaComponent } from './component/courses/java/java.component';
import { PythonComponent } from './component/courses/python/python.component';
import { HomeComponent } from './component/home/home.component';
import { NotFoundComponent } from './component/not-found/not-found.component';
import { PhotosComponent } from './component/photos/photos.component';
import { PostsComponent } from './component/posts/posts.component';
import { TodosComponent } from './component/todos/todos.component';
import { UsersComponent } from './component/users/users.component';

const routes: Routes = [
  {path:'',component: HomeComponent},
  {path:'courses',component:CoursesComponent,children:[
    {path:'java',component:JavaComponent},
    {path:'python',component:PythonComponent}
  ]},
  {path:'contact',component:ContactComponent},
  {path:'posts',component:PostsComponent},
  {path:'comments',component:CommentsComponent},
  {path:'users',component:UsersComponent},
  {path:'todos',component:TodosComponent},
  {path:'albums',component:AlbumsComponent},
  {path:'photos',component:PhotosComponent},
  {path:'**',component:NotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
